<div class="col-md-12 col-lg-12 d-none d-md-flex sidebar"><!-- start of a sidebar item -->
	<?php dynamic_sidebar( 'primary' ); ?>
</div><!-- #primary-sidebar -->